
import java.util.*;

public class QueuingJava {
    public static int numOfCustomers;
    public static void main(String[] args) {
        // create scanner for user input
        Scanner scanner = new Scanner(System.in);
        Random randService = new Random();

        // get user input for number of customers and simulation termination

        System.out.print("Enter the simulation termination option (1 for number of customers, 2 for number of minutes): ");
        int terminationOption = scanner.nextInt();
        int terminationValue = 0;
        if (terminationOption == 1) {
            System.out.print("Enter the number of customers: ");
            numOfCustomers = scanner.nextInt();
            terminationValue = numOfCustomers;
        } else if (terminationOption == 2) {
            System.out.print("Enter the number of minutes to terminate the simulation: ");
            terminationValue = scanner.nextInt();
        } else {
            System.out.println("Invalid input. Simulation terminated.");
            System.exit(0);
        }

        // initialize variables
        double arrivalRate = 0.125;
        double[] serviceProbabilities = {0.15, 0.30, 0.25, 0.20, 0.10};
        int[] serviceTimes = {1, 2, 3, 4, 5};

        // create random number generator for interarrival times and service times
        Random rand = new Random();

        // initialize arrays to store customer data
        int[] customerNumber = new int[numOfCustomers];
        int[] interarrivalTime = new int[numOfCustomers];
        int[] arrivalTime = new int[numOfCustomers];
        int[] serviceTime = new int[numOfCustomers];
        int[] timeServiceBegins = new int[numOfCustomers];
        int[] waitingTime = new int[numOfCustomers];
        int[] timeServiceEnds = new int[numOfCustomers];
        int[] timeSpentInSystem = new int[numOfCustomers];
        int[]idleTime = new int [numOfCustomers];

        // initialize variables to track simulation statistics
        int currentTime = 0;

        int[] serverStatus = new int[numOfCustomers];

        // simulate customer arrivals and service
        for (int i = 0; i < numOfCustomers && currentTime < terminationValue; i++) {
            customerNumber[i] = i + 1;

            // calculate interarrival times and arrival times for customers
            if (i == 0) {
                interarrivalTime[i] = 0;
                arrivalTime[i] = 0;
            } else {
                int interarrivalRand = randService.nextInt(8) + 1; // generate a random integer between 1 and 8
                interarrivalTime[i] = interarrivalRand;
                arrivalTime[i] = arrivalTime[i - 1] + interarrivalTime[i];
            }

            // calculate service times and time service begins for customers
            int serviceTimeIndex = -1;
            double serviceProbability = rand.nextDouble();
            for (int j = 0; j < serviceProbabilities.length; j++) {
                if (serviceProbability <= serviceProbabilities[j]) {
                    serviceTimeIndex = j;
                    break;
                }
            }
            if (serviceTimeIndex == -1) {
                serviceTimeIndex = serviceProbabilities.length - 1;
            }
            serviceTime[i] = serviceTimes[serviceTimeIndex];
            if (i == 0 || arrivalTime[i] >= timeServiceEnds[i - 1]) {
                timeServiceBegins[i] = arrivalTime[i];
                serverStatus[i] = 1;
            }
        }
        // calculate the timeServiceBegins for each customer
        for (int i = 0; i < timeServiceBegins.length; i++) {
            if (i == 0 || arrivalTime[i] >= timeServiceEnds[i - 1]) {
                timeServiceBegins[i] = arrivalTime[i];
            } else {
                timeServiceBegins[i] = timeServiceEnds[i - 1];
            }
        }
        // calculate the timeServiceEnds for each customer
        for (int i = 0; i < timeServiceEnds.length; i++) {
            timeServiceEnds[i] = timeServiceBegins[i] + serviceTime[i];
        }
        // calculate the timeSpentOnSystem for each customer
        for (int i = 0; i < timeSpentInSystem.length; i++) {
            timeSpentInSystem[i] = serviceTime[i] + waitingTime[i];
        }
        // calculate the server idle time
        for (int i = 0; i < serverStatus.length; i++) {
            serverStatus[i] = timeServiceEnds[i] - timeServiceBegins[i];
        }
        // calculate for the waiting time
        for (int i = 0; i < waitingTime.length; i++) {
            waitingTime[i] = arrivalTime[i]-timeServiceBegins[i];
        }
        QueuingJava.printTable(customerNumber, interarrivalTime, arrivalTime, serviceTime,
                timeServiceBegins, waitingTime, timeServiceEnds, timeSpentInSystem, serverStatus);

    }
    public static void printTable(int[] customerNumber, int[] interarrivalTime, int[] arrivalTime, int[] serviceTime,
                                  int[] timeServiceBegins, int[] waitingTime, int[] timeServiceEnds,
                                  int[] timeSpentInSystem, int[] serverStatus) {
        System.out.printf("%-15s%-20s%-15s%-15s%-25s%-20s%-20s%-25s%-20s\n",
                "Customer #", "Interarrival Time", "Arrival Time", "Service Time", "Time Service Begins",
                "Waiting Time", "Time Service Ends", "Time Spent in System", "Server Idle Time");
        for (int i = 0; i < customerNumber.length; i++) {
            System.out.printf("%-15d%-20d%-15d%-15d%-25d%-20d%-20d%-25d%-20d\n",
                    customerNumber[i], interarrivalTime[i], arrivalTime[i], serviceTime[i],
                    timeServiceBegins[i], waitingTime[i], timeServiceEnds[i], timeSpentInSystem[i], serverStatus[i]);

        }
       // System.out.printf("Total server idle time: %d minutes\n", idleTime);
    }

}